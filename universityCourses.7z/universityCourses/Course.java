package universityCourses;

import java.util.ArrayList;

class Course {
    private int courseID;
    private String courseName;
    private int credits;
    private Faculty faculty;
    private ArrayList<Student> enrolledStudents;

    public Course(int courseID, String courseName, int credits) {
        this.courseID = courseID;
        this.courseName = courseName;
        this.credits = credits;
        this.enrolledStudents = new ArrayList<>();
    }

    public int getCourseID() {
        return courseID;
    }

    public void setCourseID(int courseID) {
        this.courseID = courseID;
    }

    public String getCourseName() {
        return courseName;
    }

    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }

    public int getCredits() {
        return credits;
    }

    public void setCredits(int credits) {
        this.credits = credits;
    }

    public Faculty getFaculty() {
        return faculty;
    }

    public void setFaculty(Faculty faculty) {
        this.faculty = faculty;
    }

    public ArrayList<Student> getEnrolledStudents() {
        System.out.println(this.enrolledStudents);
        return enrolledStudents;
    }

    public void addStudent(Student student) {
        if (!enrolledStudents.contains(student)) {
            enrolledStudents.add(student);
            student.addCourse(this);
        } else {
            System.out.println("Student already enroll in -> course.");
        }
    }

    public void removeStudent(Student student) {
        if (enrolledStudents.contains(student)) {
            enrolledStudents.remove(student);
            student.removeCourse(this);
        } else {
            System.out.println("Student  not enroll in -> course.");
        }
    }

    @Override
    public String toString() {
        return courseID +" "+ " "+courseName +" " +credits ;
    }
}