package universityCourses;

import java.util.ArrayList;

class Student {
    private int studentID;
    private String studentName;
    private String major;
    private ArrayList<Course> enrolledCourses;

    public Student(int studentID, String studentName, String major) {
        this.studentID = studentID;
        this.studentName = studentName;
        this.major = major;
        this.enrolledCourses = new ArrayList<>();
    }

    public int getStudentID() {
        return studentID;
    }

    public void setStudentID(int studentID) {
        this.studentID = studentID;
    }

    public String getStudentName() {
        return studentName;
    }

    public void setStudentName(String studentName) {
        this.studentName = studentName;
    }

    public String getMajor() {
        return major;
    }

    public void setMajor(String major) {
        this.major = major;
    }

    public ArrayList<Course> getEnrolledCourses() {
        System.out.println(this.enrolledCourses);
        return enrolledCourses;
    }

    public void addCourse(Course course) {
        if (!enrolledCourses.contains(course)) {
            enrolledCourses.add(course);
            course.addStudent(this);
        } else {
            System.out.println("Student is already enrolled in this course.");
        }
    }

    public void removeCourse(Course course) {
        if (enrolledCourses.contains(course)) {
            enrolledCourses.remove(course);
            course.removeStudent(this);
        } else {
            System.out.println("Student is not enrolled in this course.");
        }
    }

    @Override
    public String toString() {
        return  studentID + " "+
               " " +studentName +
                 " "+major ;
    }
}
