public class Staff extends Person {

    private String employeeID;
    private String department;

    //Constructor
    public Staff(String name, int age, String address, String employeeID, String department) {

        super(name, age, address);
        this.employeeID = employeeID;
        this.department = department;
    }

    public Staff() {
        
    }

    //Getters and Setters
    public String getEmployeeID() {
        return employeeID;
    }

    public void setEmployeeID(String employeeID) {
        this.employeeID = employeeID;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }
}