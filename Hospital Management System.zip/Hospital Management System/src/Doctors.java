import java.util.ArrayList;

public class Doctors extends Staff {

    private String specialization;
    private ArrayList<Patient> patients;
    
    // Constructor
    public Doctors(String name, int age, String address, String employeeID, String department, String specialization,
            ArrayList<Patient> patients) {
        super(name, age, address, employeeID, department);
        this.specialization = specialization;
        this.patients = patients;
    }
    
    public Doctors(String name, int age, String address, String employeeID, String department, String specialization) {
        super(name, age, address, employeeID, department);
        this.specialization = specialization;
        this.patients = new ArrayList<>();
    }
        
    public Doctors() {

    }

    // Methodes
    public void addPatient(Patient patient) {
        this.patients.add(patient);
    }

    public void removePatient(Patient patient) {
        this.patients.remove(patient);
    }

    // Getters and Setters
    public String getSpecialization() {
        return specialization;
    }

    public void setSpecialization(String specialization) {
        this.specialization = specialization;
    }

    public ArrayList<Patient> getPatients() {
        return patients;
    }

    public void setPatients(ArrayList<Patient> patients) {
        this.patients = patients;
    }
}