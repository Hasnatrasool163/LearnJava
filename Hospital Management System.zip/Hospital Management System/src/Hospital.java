import java.util.ArrayList;

public class Hospital {

    private String hospitalName;
    private ArrayList<Doctors> doctors ;
    private ArrayList<Patient> patients ;
    private ArrayList<Appointment> appointments ;

    // Constructors
    public Hospital(String hospitalName) {
        this.hospitalName = hospitalName;
        this.doctors = new ArrayList<>();
        this.patients = new ArrayList<>();
        this.appointments = new ArrayList<>();
    }

    public Hospital(String hospitalName, ArrayList<Doctors> doctors, ArrayList<Patient> patients,
            ArrayList<Appointment> appointments) {
        this.hospitalName = hospitalName;
        this.doctors = doctors;
        this.patients = patients;
        this.appointments = appointments;
    }

    public Hospital() {}

    //Methods
    public void addDoctor(Doctors doctor) {
        this.doctors.add(doctor);
    }

    public void registerPatient(Patient patient) {
        this.patients.add(patient);
    }

    public void scheduleAppointment(Appointment appointment) {
        this.appointments.add(appointment);
    }

    public void cancelAppointment(Appointment appointment) {
        this.appointments.remove(appointment);
    }
    
    //Getters and Setters
    public String getHospitalName() {
        return hospitalName;
    }

    public void setHospitalName(String hospitalName) {
        this.hospitalName = hospitalName;
    }

    public ArrayList<Doctors> getDoctors() {
        return doctors;
    }

    public void setDoctors(ArrayList<Doctors> doctors) {
        this.doctors = doctors;
    }

    public ArrayList<Patient> getPatients() {
        return patients;
    }

    public void setPatients(ArrayList<Patient> patients) {
        this.patients = patients;
    }

    public ArrayList<Appointment> getAppointments() {
        return appointments;
    }

    public void setAppointments(ArrayList<Appointment> appointments) {
        this.appointments = appointments;
    } 
}