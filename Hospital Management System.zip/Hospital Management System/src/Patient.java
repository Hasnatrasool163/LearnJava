import java.util.ArrayList;

public class Patient extends Person {

    private String patientID;
    private ArrayList<String> medicalHistory ;
    private ArrayList<Appointment> appointments ;

    //Constructor
    public Patient(String name, int age, String address, String patientID, ArrayList<String> medicalHistory,
            ArrayList<Appointment> appointments) {
        super(name, age, address);
        this.patientID = patientID;
        this.medicalHistory = medicalHistory;
        this.appointments = appointments;
    }

    public Patient(String name, int age, String address, String patientID) {
        super(name, age, address);
        this.patientID = patientID;
        this.medicalHistory = new ArrayList<>();
        this.appointments = new ArrayList<>();
    }

    public Patient(){

    }

    //Method to add Medical History
    public void addMedicalHistory(String history) {
        this.medicalHistory.add(history);
    }

    public void addAppointment(Appointment entryAppointment) {
        appointments.add(entryAppointment);
    }

    //Getters and Setters
    public String getPatientID() {
        return patientID;
    }

    public void setPatientID(String patientID) {
        this.patientID = patientID;
    }

    public ArrayList<String> getMedicalHistory() {
        return medicalHistory;
    }

    public void setMedicalHistory(ArrayList<String> medicalHistory) {
        this.medicalHistory = medicalHistory;
    }

    public ArrayList<Appointment> getAppointments() {
        return appointments;
    }

    public void setAppointments(ArrayList<Appointment> appointments) {
        this.appointments = appointments;
    }
}