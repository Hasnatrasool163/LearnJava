public class App {
    public static void main(String[] args) {
        
        Hospital hospital = new Hospital("Hospital");

        Doctors doctor1 = new Doctors("Dr. Ali", 28, "Faisalabad", "FSD-197", "Child", "Child Specilist" );
        Doctors doctor2 = new Doctors("Dr. Raza", 35, "Lahore", "KHR-189", "All", "MBBS");
    
        Patient patient1 = new Patient("Hussnain", 20, "Chak No.189", "FA23-197");
        Patient patient2 = new Patient("Raza", 4, "Lahore", "ID-5001");
        
        Appointment appointment1 = new Appointment("AM-17", "FEB-12, 2024", patient1, doctor1);
        Appointment appointment2 = new Appointment("PM-29", "March-12, 2024", patient2, doctor2);

        hospital.addDoctor(doctor1);
        hospital.addDoctor(doctor2);

        hospital.registerPatient(patient1);
        hospital.registerPatient(patient2);
    
        hospital.scheduleAppointment(appointment1);
        hospital.scheduleAppointment(appointment2);

        System.out.println("Hospital Overview: " + hospital.getHospitalName());
        
        System.out.println("Doctors");
        for(Doctors doctor : hospital.getDoctors()) {
            System.out.println(doctor.getName() + " - " + doctor.getSpecialization());
        }

        System.out.println("\nPatients:");
        for(Patient patient : hospital.getPatients()) {
            System.out.println(patient.getName() + " - " + patient.getPatientID());
        }

        System.out.println("\nAppointments");
        for(Appointment appointment : hospital.getAppointments()) {
            System.out.println("Appointment ID: "+appointment.getAppointmentID() + ", Date: " + appointment.getDate() +
            ", Patient: " + appointment.getPatient().getName() + ", Doctor" + appointment.getDoctor().getName());
        }



    }
}
