package universityCourses;

import java.util.ArrayList;

class Faculty {
    private int facultyID;
    private String facultyName;
    private String department;
    private ArrayList<Course> coursesTaught;

    public Faculty(int facultyID, String facultyName, String department) {
        this.facultyID = facultyID;
        this.facultyName = facultyName;
        this.department = department;
        this.coursesTaught = new ArrayList<>();
    }

    public int getFacultyID() {
        return facultyID;
    }

    public void setFacultyID(int facultyID) {
        this.facultyID = facultyID;
    }

    public String getFacultyName() {
        return facultyName;
    }

    public void setFacultyName(String facultyName) {
        this.facultyName = facultyName;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public ArrayList<Course> getCoursesTaught() {
        return coursesTaught;
    }

    public void addCourse(Course course) {
        coursesTaught.add(course);
        course.setFaculty(this);
    }

    public void removeCourse(Course course) {
        if (coursesTaught.contains(course)) {
            coursesTaught.remove(course);
            course.setFaculty(null);
        } else {
            System.out.println("Faculty is not teaching this course.");
        }
    }

    @Override
    public String toString() {
        return facultyID +" " +facultyName +" " +department;
    }
}