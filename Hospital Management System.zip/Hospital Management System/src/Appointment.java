public class Appointment {

    private String appointmentID;
    private String date;
    private Patient patient;
    private Doctors doctor;

    // Constructor
    public Appointment(String appointmentID, String date, Patient patient, Doctors doctor) {
        this.appointmentID = appointmentID;
        this.date = date;
        this.patient = patient;
        this.doctor = doctor;
    }
    
    public Appointment() {

    }

    // Getters and Setters
    public String getAppointmentID() {
        return appointmentID;
    }

    public void setAppointmentID(String appointmentID) {
        this.appointmentID = appointmentID;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public Patient getPatient() {
        return patient;
    }

    public void setPatient(Patient patient) {
        this.patient = patient;
    }

    public Doctors getDoctor() {
        return doctor;
    }

    public void setDoctor(Doctors doctor) {
        this.doctor = doctor;
    }  
}