package universityCourses;//package universityCourses;
//
//public class DriverClass {
//
//    public static  void main(String []args) {
//
//        Faculty newfaculty = new Faculty(1, "Ahmad", "IT");
//        Faculty newfaculty1 = new Faculty(2, "Ali", "MATHS");
//
//        Course course1 = new Course(1, "OOP", 4,newfaculty);
//        Course newcourse1 = new Course(2, "DS", 3,newfaculty1);
//
//        Student std1 = new Student(1, "haris", "Web");
//        Student std2 = new Student(2, "Hamnan", "AI");
//
//        try{
//            course1.addStudent(std1);
//            course1.addStudent(std2);
//        }
//        catch(Exception e) {
//            System.out.println("Error on line 21");
//        }
//        System.out.println("Students enrolled in "+course1.getCourseName());
//        for (Student student : course1.getEnrolledStudent()){
//            System.out.println(student.getEnrolledCourses());
//        }
//
//        System.out.println("\n Courses taught by Ahmad");
//        for (Course course : newfaculty.getCoursesTought()){
//            System.out.println(course.getCourseName());
//        }
//
//        course1.removeStudent(std2);
//
//        System.out.println("updated"+course1.getCourseName());
//        for(Student student : course1.getEnrolledStudent()){
//            System.out.println(student.getStudentName());
//        }
//
//
//
//    }
//}


public class DriverClass {

        public static void main(String[] args) {

            Course course1 = new Course(1, "Java Programming", 3);
            Course course2 = new Course(2, "Database Management", 4);

            Faculty faculty1 = new Faculty(101, "Ali", "Computer Science");
            Faculty faculty2 = new Faculty(102, "Ahmad", "Information Technology");

            Student student1 = new Student(1001, "Adnan", "Computer Science");
            Student student2 = new Student(1002, "Amjad", "Information Technology");

            System.out.println(student1.getStudentID());
            System.out.println(student1.getStudentName());
            System.out.println(student2.getStudentID());
            System.out.println(student2.getStudentName());


            course1.setFaculty(faculty1);
            course2.setFaculty(faculty2);

            faculty1.addCourse(course1);
            faculty2.addCourse(course2);

            student1.addCourse(course1);
            student2.addCourse(course2);



            System.out.println(student1.getEnrolledCourses());
            System.out.println("Enrolled students in course1: " + course1.getEnrolledStudents());
            System.out.println("Courses taught by faculty1: " + faculty1.getCoursesTaught());
            System.out.println("Courses enrolled in by student1: " + student1.getEnrolledCourses());

//            course1.addStudent(student2);
        }
    }